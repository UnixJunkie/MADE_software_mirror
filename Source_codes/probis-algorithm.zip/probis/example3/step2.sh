#!/bin/bash

# Step 2: Compare 1phr (whole protein surface) against other
# protein structures (surfaces).

qsub -N probisex3 probis-job.qsub
