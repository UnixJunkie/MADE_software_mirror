#!/bin/bash

# Step 2: Compare 1phr's SO4 binding site against other
# protein structures (surfaces).

qsub -N probisex5 probis-job.qsub
