#!/bin/bash

probisexe=/v/apps/probis/gsl2-ompi184/probis

$probisexe -compare -super -f1 1phr.pdb -c1 A -f2 3jvi.pdb -c2 A
