#ifndef _SCHMITT_H
#define _SCHMITT_H

class Schmitt {
 public:
  int mnsp;
  bool compare_single(Schmitt*);
};


#endif // _SCHMITT_H
