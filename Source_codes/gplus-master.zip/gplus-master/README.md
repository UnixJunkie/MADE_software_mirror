# GANGSTA+
## Non-Sequential Protein Structure Alignment Algorithm
### Please cite: https://onlinelibrary.wiley.com/doi/abs/10.1110/ps.035469.108
### Arbeitsgruppe Knapp - Freie Universität Berlin

https://en.wikipedia.org/wiki/MIT_License

### 1. Build executable
`make`

### 2. Run example
`./gplus d2uaga1.pdb d1gkub1.pdb`
